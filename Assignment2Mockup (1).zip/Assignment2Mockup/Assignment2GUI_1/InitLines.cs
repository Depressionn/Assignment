﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Assignment2GUI_1 {
	class InitLines {
		private List<Line> lines = new List<Line>();
		private SqlConnection conn;

		public InitLines(string connStr) {
			InitTables it = new InitTables(connStr);
			conn = new SqlConnection(connStr);
			makeObj();
		}//constructor

		public List<Line> Lines {
			get { return this.lines; }
		}

		private void makeObj() {
			initLineObjs();
			createStationObj(getJunctionNames());
		}

		private List<string> getJunctionNames() {
			try {
				conn.Open();
				string commandStr = "select stationName from stations group by stationName having count(*) > 1";
				//queries for the junctions

				SqlDataReader reader = new SqlCommand(commandStr, conn).ExecuteReader();
				List<string> returnList = new List<string>();
				while (reader.Read())
					returnList.Add(reader["stationName"].ToString());
				return returnList;
			}
			catch (Exception ex) {
				Console.WriteLine("Error at junctionNames");
				Console.WriteLine(ex.Message);
				return null;
			}
			finally {
				conn.Close();
			}
		}//gets a list of junction names

		private void initLineObjs() {
			try {
				conn.Open();
				string commandStr = "select * from lines";
				SqlDataReader reader = new SqlCommand(commandStr, conn).ExecuteReader();
				while (reader.Read())
					lines.Add(new Line(reader["lineName"].ToString(), reader["lineId"].ToString()));
			}
			catch (Exception ex) {
				Console.WriteLine("Error at init lines");
				Console.WriteLine(ex.Message);
			}
			finally {
				conn.Close();
			}
		}//makes the lines

		private void createStationObj(List<string> junctions) {
			try {
				conn.Open();

				List<Station> listOfJunctions = new List<Station>();
				junctions.ForEach(x => {
					listOfJunctions.Add(new Junction(x));
				});

				//SqlCommand command = new SqlCommand();
				//command.Connection = conn;
				//command.CommandText = "select * from stations where linebelong = @yfuyjg order by stationNumber";
				lines.ForEach(x => {
					string commandStr = "select * from stations where linebelong = '" + x.Id + "' order by stationNumber";

					//command.Parameters.AddWithValue("@yfuyjg", x.Id);
					//SqlDataReader reader = command.ExecuteReader();
					SqlDataReader reader = new SqlCommand(commandStr, conn).ExecuteReader();
					while (reader.Read()) {
						if (!junctions.Contains(reader["stationName"].ToString())) {
							x.Stations.Add(new Station(reader["stationName"].ToString(), x, int.Parse(reader["stationNumber"].ToString())));
						}
						else {
							x.Stations.Add(listOfJunctions[findJunctionIndex(reader["stationName"].ToString(), junctions)]);
							x.Stations.Last().setupJunction(x, int.Parse(reader["stationNumber"].ToString()));
						}
					}
					reader.Close();
				});

			}
			catch (Exception ex) {
				Console.WriteLine("Error at creating station objs");
				Console.WriteLine(ex.Message);
			}
			finally {
				conn.Close();
			}
		}//make station objs

		private int findJunctionIndex(string name, List<string> input) {
			for (int count = 0; count <= input.Count() - 1; count++) {
				if (input[count].Equals(name))
					return count;
			}
			return -1;
		}//finding index of junction

	}
}
