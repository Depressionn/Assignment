﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.IO;

namespace Assignment2GUI_1 {
	class InitTables {
		private SqlConnection conn;
		private int temp = 0;

		public InitTables(string connStr) {
			using (this.conn = new SqlConnection(connStr)) {
				createLineTable();
				createStationTable();
				fillStationTable();
				fillLineTable();
				string[] txtFare = File.ReadAllLines(@"Resources/fares.txt");
				//createFareTable();
				//this.temp = txtFare.Length;
				//fillFareTable(0, txtFare.Length);

				createPathTable();

			}
		}//default

		private void createStationTable() {
			try {
				string commandStr = "Create table stations ("
					+ "stationName varchar(50) not null, "
					+ "stationId varchar(5) not null, "
					+ "stationNumber int not null, "
					+ "lineBelong char(2) not null, "
					+ "primary key (stationId) )";
				conn.Open();
				SqlCommand command = new SqlCommand(commandStr, conn);
				command.ExecuteNonQuery();
			}
			catch (Exception ex) {
				if (ex.Message.Equals("There is already an object named 'stations' in the database.")) {
					conn.Close();
					dropTable("stations");
					createStationTable();
				}
				else {
					Console.WriteLine("Error at create stationTable");
					Console.WriteLine(ex.Message);
				}
			}
			finally {
				conn.Close();
			}

		}//makes station tables

		private void createLineTable() {
			try {
				string commandStr = "create table lines("
					+ "lineName varchar(50) not null, "
					+ "lineId char(2) not null, "
					+ "primary key (lineId) )";
				conn.Open();
				SqlCommand command = new SqlCommand(commandStr, conn);
				command.ExecuteNonQuery();
			}
			catch (Exception ex) {
				if (ex.Message.Equals("There is already an object named 'lines' in the database.")) {
					conn.Close();
					dropTable("lines");
					createLineTable();
				}
				else {
					Console.WriteLine("Error at create stationTable");
					Console.WriteLine(ex.Message);
				}
			}
			finally {
				conn.Close();
			}
		}//make line tables

		private void fillStationTable() {
			try {
				conn.Open();
				string[] txtLines = File.ReadAllLines(@"Resources\MRT.txt");
				for (int count = 0; count <= txtLines.Length - 1; count++) {
					string commandStr = "";
					if (!txtLines[count].StartsWith("(")) {
						commandStr = "insert into stations values ('"
							+ txtLines[count + 1] + "','"
							+ txtLines[count] + "','"
							+ int.Parse(txtLines[count].Substring(2)) + "','"
							+ txtLines[count].Substring(0, 2) + "')";
						count++;
					}

					if (!commandStr.Equals("")) {
						SqlCommand command = new SqlCommand(commandStr, conn);
						command.ExecuteNonQuery();
					}
				}
			}
			catch (Exception ex) {
				Console.WriteLine("Error at fill station table");
				Console.WriteLine(ex.Message);
			}
			finally {
				conn.Close();
			}
		}//fills up station table

		private void fillLineTable() {
			try {
				conn.Open();
				string[] txtLine = File.ReadAllLines(@"Resources\lineNames.txt");
				for (int count = 1; count <= txtLine.Length - 1; count++) {
					string commandStr = "insert into lines values ('"
						+ txtLine[count + 1] + "','"
						+ txtLine[count] + "')";
					count++;

					SqlCommand command = new SqlCommand(commandStr, conn);
					command.ExecuteNonQuery();
				}
			}
			catch (Exception ex) {
				Console.WriteLine("Error at fill line table");
				Console.WriteLine(ex.Message);
			}
			finally {
				conn.Close();
			}
		}//makes the line table


		private void dropTable(string table) {
			try {
				conn.Open();
				SqlCommand command = new SqlCommand("drop table " + table, conn);
				command.ExecuteNonQuery();
			}
			catch (Exception ex) {
				Console.WriteLine("Error at dropping " + table);
				Console.WriteLine(ex.Message);
			}
			finally {
				conn.Close();
			}
		}//drops table
	
		//Fares stuff
		private void createFareTable() {
			try {
				conn.Open();
				string commandStr = "Create table fares ("
					+ "station1 varchar(50) not null, "
					+ "station2 varchar(50) not null, "
					+ "money1 decimal(3, 2) not null, "
					+ "money2 decimal(3, 2) not null, "
					+ "time int not null, "
					+ ")";
				SqlCommand command = new SqlCommand(commandStr, conn);
				command.ExecuteNonQuery();
			}
			catch (Exception ex) {
				if (ex.Message.Equals("There is already an object named 'fares' in the database.")) {
					conn.Close();
					dropTable("fares");
					createFareTable();
				}
				else {
					Console.WriteLine("Error at create fareTable");
					Console.WriteLine(ex.Message);
				}
			}
			finally {
				conn.Close();
			}
		}//make fare table

		private void fillFareTable(int start, int end) {
			try {
				conn.Open();
				string[] txtFare = File.ReadAllLines(@"Resources/fares.txt");
				for (int count = start; count <= end - 1; count++) {
					string[] parts = txtFare[count].Split(' ');
					string[] station1id = new string[3] { "", "", "" };
					for (int count2 = 0; count2 <= parts[0].Split('/').Length - 1; count2++)
						station1id[count2] = parts[0].Split('/')[count2];

					string[] station2id = new string[3];
					for (int count2 = 0; count2 <= parts[1].Split('/').Length - 1; count2++)
						station2id[count2] = parts[1].Split('/')[count2];
					List<string> temp = queryName(station1id, station2id);

					string commandStr = "insert into fares "
						+ "values ('"
						+ temp[0] + "','"
						+ temp[1] + "',"
						+ double.Parse(txtFare[count + 1].Substring(1)) + ","
						+ double.Parse(txtFare[count + 2].Substring(1)) + ","
						+ int.Parse(txtFare[count + 3]) + ")";
					Console.WriteLine(commandStr);
					SqlCommand command = new SqlCommand(commandStr, conn);
					command.ExecuteNonQuery();
					count += 3;
				}
			}
			catch (Exception ex) {
				Console.WriteLine("Error at fill fare table");
				Console.WriteLine(ex.Message);
			}
			finally {
				conn.Close();
			}
		}//fill up fare table

		private List<string> queryName(string[] arr1, string[] arr2) {
			try {
				List<string> returnList = new List<string>();
				string commandStr = "select stationName from stations where "
					+ "stationId = '" + arr1[0] + "' "
					+ "or stationId = '" + arr1[1] + "' "
					+ "or stationId = '" + arr1[2] + "' "
					+ "or stationId = '" + arr2[0] + "' "
					+ "or stationId = '" + arr2[1] + "' "
					+ "or stationId = '" + arr2[2] + "' ";

				SqlCommand command = new SqlCommand(commandStr, conn);
				SqlDataReader reader = command.ExecuteReader();
				while (reader.Read())
					returnList.Add(reader["stationName"].ToString());
				reader.Close();
				return returnList;
			}
			catch (Exception ex) {
				Console.WriteLine("Error at queryName");
				Console.WriteLine(ex.Message);
				return new List<string>() { };
			}
		}//gets query

		public void createPathTable() {
			try {
				conn.Open();
				string commandStr = "Create table pathTaken ("
					+ "stationName varchar(50) not null"
					+ ")";
				SqlCommand command = new SqlCommand(commandStr, conn);
				command.ExecuteNonQuery();
			}
			catch (Exception ex) {
				if (ex.Message.Equals("There is already an object named 'pathTaken' in the database.")) {
					conn.Close();
					dropTable("pathTaken");
					createPathTable();
				}
				else {
					Console.WriteLine("Error at create pathTable");
					Console.WriteLine(ex.Message);
				}
			}
			finally {
				conn.Close();
			}
		}//make fare table

	}//end class
}
