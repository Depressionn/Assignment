﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Assignment2GUI_1 {
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window {
		List<Line> lines;
		public MainWindow() {
			InitializeComponent();
			lines = new InitLines("server = DIT-NB1829262\\SQLEXPRESS; database = AppdAssignment; integrated security = true").Lines;
		}

		private void comboStartStation_Loaded(object sender, RoutedEventArgs e) {
			lines.ForEach(x => {
				x.Stations.ForEach(y => {
					this.comboStartStation.Items.Add(y.FullName);
				});
			});
		}

		private void comboEndStation_Loaded(object sender, RoutedEventArgs e) {
			lines.ForEach(x => {
				x.Stations.ForEach(y => {
					this.comboEndStation.Items.Add(y.FullName);
				});
			});
		}

		private void btnStart_Click(object sender, RoutedEventArgs e) {
			tabInputs.IsSelected = true;
			tabOutput.IsSelected = false;
			lblLilThing.Margin = new Thickness(0, 55, 0, 0);

		}

		private void btnEnd_Click(object sender, RoutedEventArgs e) {
			tabInputs.IsSelected = false;
			tabOutput.IsSelected = true;
			lblLilThing.Margin = new Thickness(250, 55, 0, 0);
			updatePath();

		}

		private void updatePath() {
			txtOutputPath.Text = "";

			string input = comboStartStation.Text;
			string[] parts = input.Split('[');
			Station start = new InputToStation(parts[0].Trim(), lines).ReferencedStation;

			input = comboEndStation.Text;
			parts = input.Split('[');
			Station end = new InputToStation(parts[0].Trim(), lines).ReferencedStation;

			if(start == null || end == null) {
				txtOutputPath.Text = "Unknown";
				return;
			}

			BetterFindPath path = new BetterFindPath(lines, start, end, "server = DIT-NB1829262\\SQLEXPRESS; database = AppdAssignment; integrated security = true");
			string message = "";
			path.FinalPath.ForEach(x => {
				if (message.Contains(x.FullName))
					message += "Switch here --- \r\n";
				message += x.FullName + "\r\n";
			});

			txtOutputPath.Text = message;
		}
	}//end class
}
