﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Assignment2GUI_1 {
	class BetterFindPath {
		private List<Line> lines;
		private List<Station> finalPath;
		private List<List<Station>> possiblePaths = new List<List<Station>>();
		private Station start, end;
		private SqlConnection conn;
		private double probability;
		private string money1, money2;
		private int time;
		private string connStr;

		public BetterFindPath(List<Line> lines, Station start, Station end, string connStr) {
			this.lines = lines;
			this.start = start;
			this.end = end;
			this.connStr = connStr;

			possiblePaths.Add(new Path(lines, start, end).CompletePath);
			//basic path
			initPath();
			initFinalPath();

			using (conn = new SqlConnection(connStr)) {
				queryStuff(start, end);
				fillPathTable();
			}
		}

		public int Time {
			get { return this.time; }
		}

		public string Money1 {
			get { return this.money1; }
		}

		public string Money2 {
			get { return this.money2; }
		}

		public List<Station> FinalPath {
			get { return this.finalPath; }
		}

		private List<List<Station>> repeat() {
			List<SubPath> pathToJunctions = toJunctions(start);
			//full path from start to all junctions on the lines start contains
			List<List<Station>> morePaths = new List<List<Station>>();

			pathToJunctions.ForEach(x => {
				Station currentlyAt = x.PathTaken.Last();   //junction we are at now
				Line lineUsed = findCommonLine(start, currentlyAt); //find the line used to get here
				List<Line> currentLines = currentlyAt.getLines();   //find lines the junctions contains
				currentLines.ForEach(y => {
					if (!y.Name.Equals(lineUsed.Name)) {
						List<SubPath> temp = toJunctions(currentlyAt, y);   //path from junction to next junction; excludes the line used to get here
						temp.ForEach(z => {
							List<Station> tempererer = combinePaths(x, z).PathTaken;
							morePaths.Add(tempererer);
						});
					};
				});
			});

			pathToJunctions.ForEach(x => {
				Station currentStation = x.PathTaken.Last();
				List<Station> pathFromJunctionToEnd = new Path(lines, currentStation, end).CompletePath;
				List<Station> temp = x.PathTaken;
				temp.AddRange(pathFromJunctionToEnd);
 				possiblePaths.Add(temp);
			});

			return morePaths;
		}

		private void initPath() {
			List<SubPath> pathToJunctions = toJunctions(start);
			//full path from start to all junctions on the lines start contains
			List<List<Station>> morePaths = repeat();

			List<Line> startLines = start.getLines();
			if (startLines == null)
				startLines = new List<Line>() { start.LineBelong };

			morePaths.ForEach(x => {
				Station currentStation = x.Last();
				if (currentStation.getLines().Any(o => startLines.Contains(o))) { //TEMP TODO: MAKE START.LINEBELONG INTO LIST
					List<Station> temp = new List<Station>();
					x.ForEach(y => {
						temp.Add(y);
					});
					temp.AddRange(new SubPath(currentStation, end).PathTaken);
					if(temp.Last() == end)
						possiblePaths.Add(temp);
				}
			});
		}

		private List<SubPath> toJunctions(Station start) {
			List<Line> lineBelonging = start.getLines();
			if (lineBelonging == null)
				lineBelonging = new List<Line>() { start.LineBelong };
			List<SubPath> returnList = new List<SubPath>();
			lineBelonging.ForEach(x => {
				x.Stations.ForEach(y => {
					if (y.Junction)
						returnList.Add(new SubPath(start, y));
				});
			});

			return returnList;
		}

		private List<SubPath> toJunctions(Station start, Line line) {
			List<SubPath> returnList = new List<SubPath>();
			line.Stations.ForEach(x => {
				if (x.Junction)
					returnList.Add(new SubPath(start, x, line));
			});
			return returnList;
		}

		private SubPath combinePaths(SubPath path1, SubPath path2) {
			SubPath returnPath = new SubPath();
			path1.PathTaken.ForEach(x => {
				returnPath.PathTaken.Add(x);
			});

			path2.PathTaken.ForEach(x => {
				returnPath.PathTaken.Add(x);
			});

			return returnPath;
		}

		private Line findCommonLine(Station start, Station end) {
			List<Line> lines1 = start.getLines();
			if (lines1 == null)
				lines1 = new List<Line>() { start.LineBelong };

			List<Line> lines2 = end.getLines();
			if (lines2 == null)
				lines2 = new List<Line>() { end.LineBelong };

			Line returnLine = null;
			lines1.ForEach(x => {
				lines2.ForEach(y => {
					if (x.Name.Equals(y.Name))
						returnLine = y;
				});
			});

			return returnLine;
		}//find common lines
		 //return null if no have

		private void initFinalPath() {
			int lowest = possiblePaths[0].Count();
			int indexOfLowest = 0;
			for (int count = 1; count <= possiblePaths.Count() - 1; count++) {
				if (possiblePaths[count].Count() < lowest) {
					lowest = possiblePaths[count].Count();
					indexOfLowest = count;
				}
			}

			this.finalPath = possiblePaths[indexOfLowest];
		}


		private void queryStuff(Station start, Station end) {
			try {
				conn.Open();
				string commandStr = "select distinct money1, money2, time from fares where ("
					+ "station1 = @startName and station2 = @endName) or ("
					+ "station2 = @startName and station1 = @endName)";
				SqlCommand command = new SqlCommand(commandStr, conn);
				command.Parameters.AddWithValue("@startName", start.StationName);
				command.Parameters.AddWithValue("@endName", end.StationName);

				SqlDataReader reader = command.ExecuteReader();
				while (reader.Read()) {
					this.money1 = "$" + reader["money1"].ToString();
					this.money2 = "$" + reader["money2"].ToString();
					this.time = int.Parse(reader["time"].ToString());
				}
			}
			catch (Exception ex) {
				Console.WriteLine("Error at querying time and money");
				Console.WriteLine(ex.Message);
			}
			finally {
				conn.Close();
			}
		}

		private void fillPathTable() {
			try {
				conn.Open();
				finalPath.ForEach(x => {
					string commandStr = "insert into pathTaken values(@stationName)";
					SqlCommand command = new SqlCommand(commandStr, conn);
					command.Parameters.AddWithValue("@stationName", x.StationName);
					command.ExecuteNonQuery();
				});
			}
			catch (Exception ex) {
				Console.WriteLine("Error at filling path table");
				Console.WriteLine(ex.Message);
			}
			finally {
				conn.Close();
			}

		}
	}
}
