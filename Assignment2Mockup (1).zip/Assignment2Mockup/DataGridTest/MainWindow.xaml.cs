﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;

namespace DataGridTest {
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window {
		private string connStr = "server = DIT-NB1829262\\SQLEXPRESS; database = AppdAssignment; integrated security = true";
		private SqlConnection conn;
		private List<Line> lines = new List<Line>();

		public MainWindow() {
			InitializeComponent();
			lines = new InitLines(connStr).Lines;
			dgStations.ItemsSource = lines;
		}//on Load
	}
}
