﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MapView {
	public partial class Form1 : Form {
		private SqlConnection conn;
		public Form1() {
			InitializeComponent();
		}

		private void pictureBox1_Paint(object sender, PaintEventArgs e) {
			int totalMaxWidth = 0;
			List<string> pathTaken = new List<string>();
			try {
				using (conn = new SqlConnection("server = DIT-NB1829262\\SQLEXPRESS; database = AppdAssignment; integrated security = true")) {
					conn.Open();
					SqlCommand command = new SqlCommand("select * from pathTaken", conn);
					SqlDataReader reader = command.ExecuteReader();
					while (reader.Read())
						pathTaken.Add(reader["stationName"].ToString());
					reader.Close();
				}
			}
			catch (Exception ex) {
				Console.WriteLine("Error at getting path");
				Console.WriteLine(ex.Message);
			}
			finally {
				conn.Close();
			}
			Pen pen;

			List<string> pathNoDup = removeDuplicate(pathTaken);

			for (int count = 0; count < pathNoDup.Count(); count++) {
				List<string> stationIds = new List<string>();
				string toCompare = "EW";
				try {
					using (conn = new SqlConnection("server = DIT-NB1829262\\SQLEXPRESS; database = AppdAssignment; integrated security = true")) {
						conn.Open();
						string commandStr = "select stationId from stations where stationName ='"
							+ pathTaken[count] + "' order by case "
							+ "when stationId like '%" + toCompare + "%' then 1 "
							+ "else 5 end";

						SqlCommand command = new SqlCommand(commandStr, conn);
						SqlDataReader reader = command.ExecuteReader();
						while (reader.Read())
							stationIds.Add(reader["stationId"].ToString());
						reader.Close();
					}
				}
				catch (Exception ex) {
					Console.WriteLine("Error at getting stations");
					Console.WriteLine(ex.Message);
				}
				finally {
					conn.Close();
				}

				totalMaxWidth += 45;
				//init colours
				SolidBrush b = new SolidBrush(Color.White);
				pen = new Pen(Color.Black, 1F);
				Rectangle r = new Rectangle(30 + (count * 40), 0, 30, 30);

				string msg = "";
				float degree = 360 / stationIds.Count();
				float tilt = 0;
				for(int count2 = 0; count2 <= stationIds.Count() - 1; count2++) {
					//inner circle
					b.Color = Color.White;
					Rectangle inner = new Rectangle(30 + (count * 40) + 6, 6, 18, 18);
					e.Graphics.DrawEllipse(pen, inner);
					e.Graphics.FillEllipse(b, inner);

					Color secondColor = getColor(stationIds[count2].Substring(0, 2));
					b.Color = secondColor;
					pen.Color = secondColor;
					//fill cricle 
					e.Graphics.FillPie(b, r, tilt, degree);
					//outer arc
					e.Graphics.DrawArc(pen, r, tilt, degree);
					//inner arc
					e.Graphics.DrawArc(pen, inner, tilt, degree);
					
					tilt += degree;
					//inner circle
					b.Color = Color.White;
					e.Graphics.FillEllipse(b, inner);

					msg += stationIds[count2] + "\n";
				}

				e.Graphics.DrawString(msg, new Font("Arial", 10), Brushes.Black, 30 + (count * 40), 40);
			}

			//drawing connectors
			pen = new Pen(Color.Black, 5.0F);
			for (int count = 0; count < pathTaken.Count() - 1; count++) {
				//Color colorToUse = getColor();
				e.Graphics.DrawLine(pen, 60 + (count * 40), 15, 70 + (count * 40), 15);
			}

			pictureBox1.Width = totalMaxWidth;
			pen.Dispose();
		}

		private Color getColor(string id) {
			switch (id) {
				case "CC": return Color.Yellow;
				case "EW": return Color.Green;
				case "NE": return Color.Purple;
				case "DT": return Color.Blue;
				case "NS": return Color.Red;
				default: return Color.Black;
			}
		}//gets line colour

		private string findSameLine(List<string> list1, List<string> list2) {
			string returnStr = "";
			list1.ForEach(x => {
				list2.ForEach(y => {
					if (x.Equals(y))
						returnStr = x;
				});
			});

			return returnStr;
		}

		private List<string> removeDuplicate(List<string> input) {
			List<string> returnList = new List<string>();
			input.ForEach(x => {
				if (!returnList.Contains(x))
					returnList.Add(x);
			});
			return returnList;
		}
	}
}
