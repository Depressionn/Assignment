﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.IO;

namespace Assignment2Mockup {
	class Path {
		private List<SubPath> subPaths = new List<SubPath>();
		private List<List<Station>> possiblePaths = new List<List<Station>>();
		private List<Station> completePath = new List<Station>();
		private List<Line> lines = new List<Line>();
		private List<Station> junctions = new List<Station>();
		private bool change;
		private List<Line> linesUsed = new List<Line>();
		private double probabilityOfDelay;
		private SqlConnection conn;
		private string money1, money2;
		private int time;

		public Path(List<Line> lines, Station start, Station end) {
			this.lines = lines;

			lines.ForEach(x => {
				x.Stations.ForEach(y => {
					if (y.Junction)
						junctions.Add(y);
				});
			});

			createPath(start, end);

		}//constructor without sql

		private void fillPathTable() {
			try {
				conn.Open();
				completePath.ForEach(x => {
					string commandStr = "insert into pathTaken values('"
						+ x.StationName + "')";

					SqlCommand command = new SqlCommand(commandStr, conn);
					command.ExecuteNonQuery();
				});
			}catch (Exception ex) {
				Console.WriteLine("Error at filling path table");
				Console.WriteLine(ex.Message);
			}
			finally {
				conn.Close();
			}

		}

		public List<Station> CompletePath {
			get { return completePath; }
		}

		public bool Change {
			get { return change; }
		}

		public double ProbabilityOfDelay {
			get { return this.probabilityOfDelay; }
		}

		public int Time {
			get { return this.time; }
		}

		public string Money1 {
			get { return this.money1; }
		}

		public string Money2 {
			get { return this.money2; }
		}

		private void createPath(Station start, Station end) {

			List<Line> line1 = start.getLines();
			if (line1 == null)
				line1 = new List<Line>() { start.LineBelong };
			List<Line> line2 = end.getLines();
			if (line2 == null)
				line2 = new List<Line>() { end.LineBelong };

			if (line1.Any(x => line2.Contains(x))) {    //on same line
				linesUsed.Add(findCommonLine(line1, line2));
				SubPath temp = new SubPath(start, end);
				completePath.AddRange(temp.PathTaken);
				this.change = false;
				this.probabilityOfDelay = getProbability(completePath.Count(), 0);
			}
			else {
				List<Station> junctions = findJunctions(line1, line2);
				for (int line1Count = 0; line1Count <= line1.Count() - 1; line1Count++) {
					for (int line2Count = 0; line2Count <= line2.Count() - 1; line2Count++) {
						for (int count = 0; count <= junctions.Count() - 1; count++) {
							if (line1[line1Count].Stations.Contains(junctions[count]) && line2[line2Count].Stations.Contains(junctions[count])) {
								SubPath temp = new SubPath(start, junctions[count]);
								possiblePaths.Add(temp.PathTaken);
								temp = new SubPath(junctions[count], end);
								List<Station> extendedPath = combinedLists(possiblePaths.Last(), temp.PathTaken);
								possiblePaths[possiblePaths.Count() - 1] = extendedPath; //change last item in array
							}
						}
						completePath = possiblePaths[indexOfSmallestList(possiblePaths)];
						completePath = removeExtras(completePath, end);
						linesUsed.Add(findCommonLine(line1, junctions[indexOfSmallestList(possiblePaths)].getLines()));
						linesUsed.Add(findCommonLine(junctions[indexOfSmallestList(possiblePaths)].getLines(), line2));
						this.change = true;
						this.probabilityOfDelay = getProbability(new SubPath(start, junctions[indexOfSmallestList(possiblePaths)]).PathTaken.Count(), new SubPath(junctions[indexOfSmallestList(possiblePaths)], end).PathTaken.Count());
					}
				}
			}//diff line

		}//end create path method

		private List<Station> removeExtras(List<Station> input, Station end) {
			List<Station> returnList = new List<Station>();
			for (int count = 0; count <= input.Count() - 1; count++) {
				returnList.Add(input[count]);
				if (input[count] == end)
					return returnList;
			}
			return returnList;
		}

		private List<Station> findJunction(Line line1, Line line2) {
			List<Station> returnList = new List<Station>();
			for (int count = 0; count <= line1.Stations.Count() - 1; count++) {
				for (int count1 = 0; count1 <= line2.Stations.Count() - 1; count1++) {
					if (line1.Stations[count].StationName.Equals(line2.Stations[count1].StationName)) {
						returnList.Add(line1.Stations[count]);
					}
				}
			}

			return returnList;
		}//finds junctions given two lines

		private List<Station> findJunctions(List<Line> line1, Line line2) {
			List<Station> returnList = new List<Station>();
			for (int count = 0; count <= line1.Count() - 1; count++) {
				returnList.AddRange(findJunction(line1[count], line2));
			}
			return returnList;
		}//finds junctions given a listLine and a line

		private List<Station> findJunctions(List<Line> lines1, List<Line> lines2) {
			List<Station> returnList = new List<Station>();
			for (int count = 0; count <= lines1.Count() - 1; count++) {
				for (int count2 = 0; count2 <= lines2.Count() - 1; count2++) {
					returnList.AddRange(findJunction(lines1[count], lines2[count2]));
				}
			}
			return returnList;
		}//find junctions given two list lines

		private List<Station> combinedLists(List<Station> list1, List<Station> list2) {
			List<Station> returnList = new List<Station>();
			returnList.AddRange(list1);
			returnList.AddRange(list2);
			return returnList;
		}//combines two paths into one

		private int indexOfSmallestList(List<List<Station>> input) {
			int smallestLength = input[0].Count(), returnInt = 0;
			for (int count = 1; count <= input.Count() - 1; count++) {
				int lengthOfCurrent = input[count].Count();
				if (lengthOfCurrent < smallestLength) {
					smallestLength = lengthOfCurrent;
					returnInt = count;
				}
			}
			return returnInt;
		}//finds index of smallest list

		private Line findCommonLine(List<Line> line1, List<Line> line2) {
			for (int count1 = 0; count1 <= line1.Count() - 1; count1++)
				for (int count2 = 0; count2 <= line2.Count() - 1; count2++)
					if (line1[count1] == line2[count2])
						return line1[count1];
			return null;

		}//finds the common line given two listLines
		 //first line to be found is returned

		private double getProbability(int fp, int sp) {
			double prob = 0;
			string[] failure = File.ReadAllLines(@"resources/mrtFailureStats.txt");
			double avgLengthBtwnStation = linesUsed[0].TotalLength / linesUsed[0].Stations.Count();
			double totalTraveled = fp * avgLengthBtwnStation;
			for (int lineCount = 0; lineCount <= failure.Length - 1; lineCount++) {
				if (failure[lineCount].Equals(linesUsed[0].Id)) {
					prob = (totalTraveled / double.Parse(failure[lineCount + 1])) * 100;
				}
			}

			if (sp != 0) {
				avgLengthBtwnStation = linesUsed[1].TotalLength / linesUsed[1].Stations.Count();
				totalTraveled = sp * avgLengthBtwnStation;
				for (int lineCount = 0; lineCount <= failure.Length - 1; lineCount++) {
					if (failure[lineCount].Equals(linesUsed[1].Id)) {
						prob = (prob + (totalTraveled / double.Parse(failure[lineCount + 1]) * 100)) / 2;
					}
				}
			}//if not on same line
			 //combine and find avg

			return prob;

		}//probability of delay

	}//end class
}
