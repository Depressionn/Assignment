﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace Assignment2Mockup {
	class Program {
		static void Main(string[] args) {
			InitTables it = new InitTables("server = DIT-NB1829262\\SQLEXPRESS; database = AppdAssignment; integrated security = true");
			List<Line> lines = new InitLines("server = DIT-NB1829262\\SQLEXPRESS; database = AppdAssignment; integrated security = true").Lines;

			Console.Write("Start: ");
			InputToStation start = new InputToStation(Console.ReadLine(), lines);
			if (start.ReferencedStation == null) {
				Console.WriteLine("Check inputs");
				Console.ReadKey();
				return;
			}

			Console.Write("End: ");
			InputToStation end = new InputToStation(Console.ReadLine(), lines);
			if (end.ReferencedStation == null) {
				Console.WriteLine("Check inputs");
				Console.ReadKey();
				return;
			}

			List<Line> startLine = start.ReferencedStation.getLines();
			if (startLine == null)
				startLine = new List<Line>() { start.ReferencedStation.LineBelong };

			List<Line> endLine = end.ReferencedStation.getLines();
			if (endLine == null)
				endLine = new List<Line>() { end.ReferencedStation.LineBelong };

			string txt = "";
			BetterFindPath output = new BetterFindPath(lines, start.ReferencedStation, end.ReferencedStation, "server = DIT-NB1829262\\SQLEXPRESS; database = AppdAssignment; integrated security = true");

			output.FinalPath.ForEach(x => {
				txt += x.StationName + "\r\n";
			});

			Console.WriteLine(txt);
			Console.WriteLine(output.Money1 + ", " + output.Money2 + ", " + output.Time + "mins");


			Console.WriteLine("Program end");

			Console.ReadKey();

			//Process.Start(@"MapView.exe");
		}//end main

	}//end class
}
