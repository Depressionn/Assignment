﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2Mockup {
	class SubPath {
		private List<Station> pathTaken = new List<Station>();
		private Line lineUsed;

		public SubPath() { }//default

		public SubPath(Station start, Station end) {
			this.lineUsed = findLineUsed(start, end);
			if (lineUsed != null)
				findPath(start, end);
		}

		public SubPath(Station start, Station end, Line lineToBeUsed) {
			findPath(start, end, lineToBeUsed);
		}

		private void findPath(Station start, Station end, Line lineToBeUsed) {
			int starting = lineToBeUsed.Stations.IndexOf(start);
			int ending = lineToBeUsed.Stations.IndexOf(end);
			if (starting > ending) {
				for (int count = starting; count >= ending; count--) {
					pathTaken.Add(lineToBeUsed.Stations[count]);
				}
			}
			else {
				for (int count = starting; count <= ending; count++) {
					pathTaken.Add(lineToBeUsed.Stations[count]);
				}

			}
		}

		private void findPath(Station start, Station end) {
			int starting = lineUsed.Stations.IndexOf(start);
			int ending = lineUsed.Stations.IndexOf(end);
			if (starting > ending) {
				for (int count = starting; count >= ending; count--) {
					pathTaken.Add(lineUsed.Stations[count]);
				}
			}
			else {
				for (int count = starting; count <= ending; count++) {
					pathTaken.Add(lineUsed.Stations[count]);
				}

			}
		}

		private Line findLineUsed(Station start, Station end) {
			List<Line> line1 = start.getLines();
			if (line1 == null)
				line1 = new List<Line>() { start.LineBelong };

			List<Line> line2 = end.getLines();
			if (line2 == null)
				line2 = new List<Line>() { end.LineBelong };

			for (int line1Count = 0; line1Count <= line1.Count() - 1; line1Count++) {
				for (int line2Count = 0; line2Count <= line2.Count() - 1; line2Count++) {
					if (line1[line1Count].Name.Equals(line2[line2Count].Name))
						return line1[line1Count];
				}
			}

			return null;
			//completely different lines
		}

		public List<Station> PathTaken {
			get { return pathTaken; }
			set { this.pathTaken = value; }
		}
	}//end class
}
